import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';

class EditComment extends StatefulWidget {
  const EditComment({super.key});

  @override
  _EditCommentState createState() => _EditCommentState();
}

class _EditCommentState extends State<EditComment> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
